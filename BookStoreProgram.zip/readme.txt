# Reg No : 4471 Sec A 
# Name : Abdul Latif
# BookStore Program...
//////////////////////////////////////////////////////////////////////////////
# Program State..
Its Under Developement So There Maybe Errors and Bugs..
# Do's..................
1. Replace word "cls" to "clear" at line system("cls") in Linux OS And Vice Versa..
2. Go To Admin Part And Add Books And Members To BookStore... Password is 1234
3. Use Only Options(1,3,6,7 and 8)... Others Are Under Developement..

# Problems...
getline Function Sometimes Doesn't take whole String value or 1st Character of string.

# Side Notes..
I Have Used Goto Statements And Loops To Never Stop The Program..
Because You Probably Don't Want It To Stop After Setting UP.
All The Members And Books.. You Will Lose EveryThing :) ......

It Really Need A Place To Store Data..
A DataBase Or Write Data On Files And Read Back Any Time..
Inshallah Will Compelete It With That Too Till The End Of Semester..
Adding More Functionallity Too....
